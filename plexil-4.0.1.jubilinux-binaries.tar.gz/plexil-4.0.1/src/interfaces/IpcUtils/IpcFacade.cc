/* Copyright (c) 2006-2015, Universities Space Research Association (USRA).
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universities Space Research Association nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY USRA ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL USRA BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "IpcFacade.hh"

#include "ArrayImpl.hh"
#include "Debug.hh"
#include "Error.hh"
#include "ThreadSpawn.hh"

#include <cstring>

// ooid classes
#include "uuid_gen.h"
#include "system/devrand.h"

namespace PLEXIL 
{

  /**
   * Returns a formatted message type string given the basic message type and destination ID.
   * The caller is responsible for
   * @param msgName The name of the message type
   * @param destId The destination ID for the message
   */
  static std::string formatMsgName(const std::string& msgName, const std::string& destId) {
    return destId + msgName;
  }

  /**
   * @brief Return the message format string corresponding to the message type.
   * @param typ The message type.
   * @return Const char pointer to the message format name.
   */
  static inline const char* msgFormatForType(const PlexilMsgType typ)
  {
    switch (typ) {
    case PlexilMsgType_NotifyExec:
    case PlexilMsgType_TerminateChangeLookup:
    case PlexilMsgType_UnknownValue:

      return MSG_BASE;
      break;

    case PlexilMsgType_AddPlan:
    case PlexilMsgType_AddPlanFile:
    case PlexilMsgType_AddLibrary:
    case PlexilMsgType_AddLibraryFile:
    case PlexilMsgType_Command:
    case PlexilMsgType_Message:
    case PlexilMsgType_LookupNow:
    case PlexilMsgType_LookupOnChange:
    case PlexilMsgType_PlannerUpdate:
    case PlexilMsgType_StringValue:
    case PlexilMsgType_TelemetryValues:

      return STRING_VALUE_MSG;
      break;

    case PlexilMsgType_ReturnValues:

      return RETURN_VALUE_MSG;
      break;

    case PlexilMsgType_BooleanValue:

      return BOOLEAN_VALUE_MSG;
      break;

    case PlexilMsgType_IntegerValue:

      return INTEGER_VALUE_MSG;
      break;

    case PlexilMsgType_RealValue:

      return REAL_VALUE_MSG;
      break;
              
    case PlexilMsgType_BooleanArray:
      return BOOLEAN_ARRAY_MSG;
      break;
              
    case PlexilMsgType_IntegerArray:
      return INTEGER_ARRAY_MSG;
      break;
              
    case PlexilMsgType_RealArray:
      return REAL_ARRAY_MSG;
      break;

    case PlexilMsgType_StringArray:
      return STRING_ARRAY_MSG;
      break;

    case PlexilMsgType_PairBoolean:
      return BOOLEAN_PAIR_MSG;
      break;

    case PlexilMsgType_PairInteger:
      return INTEGER_PAIR_MSG;
      break;

    case PlexilMsgType_PairReal:
      return REAL_PAIR_MSG;
      break;

    case PlexilMsgType_PairString:
      return STRING_PAIR_MSG;
      break;

    default:
      return NULL;
      break;
    }
  }

  /**
   * @brief Utility function to create a value message from a PLEXIL Value.
   * @param val The Value to encode in the message.
   * @return Pointer to newly allocated IPC message.
   * @note Returns NULL for unimplemented/invalid Values.
   */
  PlexilMsgBase *constructPlexilValueMsg(Value const val)
  {
    PlexilMsgBase *result = NULL;
    if (val.isKnown())
      switch (val.valueType()) {
      case BOOLEAN_TYPE: {
        bool b;
        val.getValue(b);
        struct PlexilBooleanValueMsg *boolMsg = new PlexilBooleanValueMsg;
        boolMsg->boolValue = (unsigned char) b;
        debugMsg("constructPlexilValueMsg", "Boolean value is " << b);
        result = (PlexilMsgBase*) boolMsg;
        result->msgType = PlexilMsgType_BooleanValue;
        break;
      }

      case INTEGER_TYPE: {
        struct PlexilIntegerValueMsg *intMsg = new PlexilIntegerValueMsg;
        val.getValue(intMsg->intValue);
        debugMsg("constructPlexilValueMsg", "Integer value is " << intMsg->intValue);
        result = (PlexilMsgBase*) intMsg;
        result->msgType = PlexilMsgType_IntegerValue;
        break;
      }

      case REAL_TYPE: {
        struct PlexilRealValueMsg *realMsg = new PlexilRealValueMsg;
        val.getValue(realMsg->doubleValue);
        debugMsg("constructPlexilValueMsg", "Real value is " << realMsg->doubleValue);
        result = (PlexilMsgBase*) realMsg;
        result->msgType = PlexilMsgType_RealValue;
        break;
      }

      case STRING_TYPE:  {
        std::string const *sp;
        val.getValuePointer(sp);
        struct PlexilStringValueMsg *stringMsg = new PlexilStringValueMsg;
        stringMsg->stringValue = sp->c_str();
        debugMsg("constructPlexilValueMsg", "String value is \"" << *sp << "\"");
        result = (PlexilMsgBase*) stringMsg;
        result->msgType = PlexilMsgType_StringValue;
        break;
      }

      case COMMAND_HANDLE_TYPE: {
        uint16_t handle;
        val.getValue(handle);
        struct PlexilCommandHandleValueMsg *handleMsg = new PlexilCommandHandleValueMsg;
        handleMsg->commandHandleValue = handle;
        result = (PlexilMsgBase *) handleMsg;
        result->msgType = PlexilMsgType_CommandHandleValue;
        break;
      }

      case BOOLEAN_ARRAY_TYPE: {
        BooleanArray const *ba = NULL;
        val.getValuePointer(ba);
        assertTrue_1(ba);
        size_t size = ba->size();
        unsigned char *bools = new unsigned char[size];
        for (size_t i = 0; i < size; i++) {
          bool b;
          assertTrue_2(ba->getElement(i, b), "Boolean array element is UNKNOWN");
          bools[i] = (unsigned char) b;
        }
        struct PlexilBooleanArrayMsg* boolArrayMsg = new PlexilBooleanArrayMsg();
        boolArrayMsg->arraySize = size;
        boolArrayMsg->boolArray = bools;
        debugMsg("constructPlexilValueMsg", "First parameter of Boolean array is " << (bool) boolArrayMsg->boolArray[0]);
        result = (PlexilMsgBase*) boolArrayMsg;
        result->msgType = PlexilMsgType_BooleanArray;
        break;
      }

      case INTEGER_ARRAY_TYPE: {
        IntegerArray const *ia = NULL;
        val.getValuePointer(ia);
        assertTrue_1(ia);
        size_t size = ia->size();
        int32_t *nums = new int32_t[size];
        for (size_t i = 0; i < size; i++) 
          assertTrue_2(ia->getElement(i, nums[i]), "Integer array element is UNKNOWN");
        struct PlexilIntegerArrayMsg* intArrayMsg = new PlexilIntegerArrayMsg();
        intArrayMsg->arraySize = size;
        intArrayMsg->intArray = nums;
        debugMsg("constructPlexilValueMsg", "First parameter of Integer array is " << intArrayMsg->intArray[0]);
        result = (PlexilMsgBase*) intArrayMsg;
        result->msgType = PlexilMsgType_IntegerArray;
        break;
      }

      case REAL_ARRAY_TYPE: {
        RealArray const *ra = NULL;
        val.getValuePointer(ra);
        assertTrue_1(ra);
        size_t size = ra->size();
        double *nums = new double[size];
        for (size_t i = 0; i < size; i++) 
          assertTrue_1(ra->getElement(i, nums[i]));
        struct PlexilRealArrayMsg* realArrayMsg = new PlexilRealArrayMsg();
        realArrayMsg->arraySize = size;
        realArrayMsg->doubleArray = nums;
        debugMsg("constructPlexilValueMsg", "First parameter of Real array is " << realArrayMsg->doubleArray[0]);
        result = (PlexilMsgBase*) realArrayMsg;
        result->msgType = PlexilMsgType_RealArray;
        break;
      }

      case STRING_ARRAY_TYPE: {
        StringArray const *sa = NULL;
        val.getValuePointer(sa);
        assertTrue_1(sa);
        size_t size = sa->size();
        const char **strings = new const char*[size];
        for (size_t i = 0; i < size; i++) {
          std::string const *temp = NULL;
          assertTrue_1(sa->getElementPointer(i, temp));
          strings[i] = temp->c_str();
        }
        struct PlexilStringArrayMsg* strArrayMsg = new PlexilStringArrayMsg();
        strArrayMsg->arraySize = size;
        strArrayMsg->stringArray = strings;
        debugMsg("constructPlexilValueMsg",
                 "First parameter of String array is \"" << strArrayMsg->stringArray[0] << "\"");
        result = (PlexilMsgBase*) strArrayMsg;
        result->msgType = PlexilMsgType_StringArray;
        break;
      }

      default:
        assertTrue_2(ALWAYS_FAIL, "Invalid or unimplemented PLEXIL data type");
        break;
      }
    else {
      // Unknown
      result = (PlexilMsgBase *) new PlexilUnknownValueMsg;
      result->msgType = PlexilMsgType_UnknownValue;
      debugMsg("constructPlexilValueMsg", " Unknown value");
    }

    return result;
  }

  /**
   * @brief Utility function to extract the value from a value message.
   * @param msg Pointer to const IPC message.
   * @return The Value represented by the message.
   * @note The returned value will be unknown if the message is not a value message.
   */
  Value getPlexilMsgValue(PlexilMsgBase const *msg)
  {
    switch ((PlexilMsgType) msg->msgType) {
    case PlexilMsgType_CommandHandleValue: {
      PlexilCommandHandleValueMsg const *param = reinterpret_cast<const PlexilCommandHandleValueMsg*> (msg);
      return Value(param->commandHandleValue, COMMAND_HANDLE_TYPE);
    }

    case PlexilMsgType_BooleanValue: {
      const PlexilBooleanValueMsg* param = reinterpret_cast<const PlexilBooleanValueMsg*> (msg);
      return Value((bool) param->boolValue);
    }

    case PlexilMsgType_IntegerValue: {
      const PlexilIntegerValueMsg* param = reinterpret_cast<const PlexilIntegerValueMsg*> (msg);
      return Value(param->intValue);
    }

    case PlexilMsgType_RealValue: {
      const PlexilRealValueMsg* param = reinterpret_cast<const PlexilRealValueMsg*> (msg);
      return Value(param->doubleValue);
    }

    case PlexilMsgType_StringValue: {
      const PlexilStringValueMsg* param = reinterpret_cast<const PlexilStringValueMsg*> (msg);
      return Value(param->stringValue);
    }

    case PlexilMsgType_BooleanArray: {
      const PlexilBooleanArrayMsg* param = reinterpret_cast<const PlexilBooleanArrayMsg*> (msg);
      BooleanArray array(param->arraySize);
      for (size_t j = 0; j < param->arraySize; j++)
        array.setElement(j, (bool) param->boolArray[j]);
      return Value(array);
    }

    case PlexilMsgType_IntegerArray: {
      const PlexilIntegerArrayMsg* param = reinterpret_cast<const PlexilIntegerArrayMsg*> (msg);
      IntegerArray array(param->arraySize);
      for (size_t j = 0; j < param->arraySize; j++)
        array.setElement(j, param->intArray[j]);
      return Value(array);
    }

    case PlexilMsgType_RealArray: {
      const PlexilRealArrayMsg* param = reinterpret_cast<const PlexilRealArrayMsg*> (msg);
      RealArray array(param->arraySize);
      for (size_t j = 0; j < param->arraySize; j++)
        array.setElement(j, param->doubleArray[j]);
      return Value(array);
    }

    case PlexilMsgType_StringArray: {
      const PlexilStringArrayMsg* param = reinterpret_cast<const PlexilStringArrayMsg*> (msg);
      StringArray array(param->arraySize);
      for (size_t j = 0; j < param->arraySize; j++)
        array.setElement(j, std::string(param->stringArray[j]));
      return Value(array);
    }

    default:
      // TODO: handle error more gracefully
      assertTrue_2(ALWAYS_FAIL, "getPlexilMsgValue: invalid or unimplemented message type");
      // fall thru...

    case PlexilMsgType_UnknownValue:
      return Value();
    }
  }

  IpcFacade::IpcFacade() :
    m_isInitialized(false),
    m_isStarted(false),
    m_stopDispatchThread(false),
    m_nextSerial(1),
    m_myUID(generateUID())
  {
    debugMsg("IpcFacade", " constructor");
  }

  IpcFacade::~IpcFacade() {
    debugMsg("IpcFacade", " destructor");
    if (m_isStarted) {
      stop();
    }
    if (m_isInitialized) {
      shutdown();
    }
    // *** why is this necessary?? ***
    if (m_mutex.isLockedByCurrentThread()) {
      debugMsg("IpcFacade", " destructor: unlocking mutex");
      m_mutex.unlock();
    }
  }

  const std::string& IpcFacade::getUID() {
    return m_myUID;
  }
  /**
   * @brief Connects to the Ipc server. This should be called before calling start().
   * If it is not, this method is called by start. If already initialized, this method
   * does nothing and returns IPC_OK.
   * @param taskName If null, the current UID of the IpcFacade is used as the task name.
   */
  IPC_RETURN_TYPE IpcFacade::initialize(const char* taskName, const char* serverName) {
    if (m_isInitialized) {
      debugMsg("IpcFacade:initialize", " already done, returning");
      return IPC_OK;
    }

    if (taskName != NULL && taskName != m_myUID)
      m_myUID = taskName;

    IPC_RETURN_TYPE result = IPC_OK;
    debugMsg("IpcFacade:initialize", " locking mutex");
    RTMutexGuard guard(m_mutex);

    // perform global initialization
    // Initialize IPC
    // possibly redundant, but always safe
    debugMsg("IpcFacade:initialize", " calling IPC_initialize()");
    result = IPC_initialize();
    if (result != IPC_OK) {
      debugMsg("IpcFacade:initialize", " IPC_initialize() failed, IPC_errno = " << IPC_errno);
      return result;
    }

    // Connect to central
    debugMsg("IpcFacade:initialize", " calling IPC_connectModule()");
    result = IPC_connectModule(m_myUID.c_str(), serverName);
    if (result != IPC_OK)
      {
        debugMsg("IpcFacade:initialize", " IPC_connectModule() failed, IPC_errno = " << IPC_errno);
        return result;
      }

    // Define messages
    debugMsg("IpcFacade:initialize", " defining message types");
    if (definePlexilIPCMessageTypes())
      {
        result = IPC_OK;
      }
    else
      {
        condDebugMsg(result == IPC_OK, "IpcFacade:initialize", " defining message types failed");
        result = IPC_Error;
      }
    if (result == IPC_OK) {
      m_isInitialized = true;
      debugMsg("IpcFacade:initialize", " succeeded");
    }
    return result;
  }

  /**
   * @brief Initializes and starts the Ipc message handling thread. If Ipc is already
   * started, this method does nothing and returns IPC_OK.
   * @return IPC_Error if the dispatch thread is not started correctly, IPC_OK otherwise
   */
  IPC_RETURN_TYPE IpcFacade::start() {
    IPC_RETURN_TYPE result = IPC_OK;
    if (!m_isInitialized || !IPC_isConnected())
      result = IPC_Error;
    debugMsg("IpcFacade:start", " locking mutex");
    RTMutexGuard guard(m_mutex);
    //perform only when this instance is the only started instance of the class
    if (result == IPC_OK && !m_isStarted) {
      // Subscribe to messages
      debugMsg("IpcFacade:start", " subscribing to messages");
      subscribeToMsgs();

      // Spawn message thread AFTER all subscribes complete
      // Running thread in parallel with subscriptions resulted in deadlocks
      debugMsg("IpcFacade:start", " spawning IPC dispatch thread");
      if (threadSpawn((THREAD_FUNC_PTR) myIpcDispatch, this, m_threadHandle)) {
        debugMsg("IpcFacade:start", " succeeded");
        m_isStarted = true;
      }
    }
    return result;
  }

  /**
   * @brief Removes all subscriptions registered by this IpcFacade. If
   * this is the only running instance of IpcFacade, stops the Ipc message
   * handling thread. If Ipc is not running, this method does nothing and returns IPC_OK.
   */
  void IpcFacade::stop() {
    if (!m_isStarted) {
      return;
    }
    debugMsg("IpcFacade:stop", " locking mutex");
    RTMutexGuard guard(m_mutex);

    // Cancel IPC dispatch thread first to prevent deadlocks
    debugMsg("IpcFacade:stop", " cancelling dispatch thread");
    m_stopDispatchThread = true;
    int myErrno = pthread_join(m_threadHandle, NULL);
    if (myErrno != 0) {
      debugMsg("IpcUtil:stop", "Error in pthread_join; errno = " << myErrno);
    }

    debugMsg("IpcFacade:stop", " unsubscribing from messages");
    unsubscribeFromMsgs();

    m_isStarted = false;
    unsubscribeAll();

  }

  /**
   * @brief Disconnects from the Ipc server. This puts Ipc back in its initial state before
   * being initialized.
   */
  void IpcFacade::shutdown() {
    debugMsg("IpcFacade::shutdown", "locking mutex");
    RTMutexGuard guard(m_mutex);
    if (m_isInitialized) {
      if (m_isStarted) {
        stop();
      }

      // Disconnect from central
      IPC_disconnect();
    }
    m_isInitialized = false;
  }

  void IpcFacade::subscribeAll(IpcMessageListener* listener) {
    m_localRegisteredHandlers.push_back(LocalListenerRef(ALL_MSG_TYPE(), listener));
    subscribeGlobal(LocalListenerRef(ALL_MSG_TYPE(), listener));
  }

  void IpcFacade::subscribe(IpcMessageListener* listener, PlexilMsgType type) {
    m_localRegisteredHandlers.push_back(LocalListenerRef((uint16_t) type, listener));
    subscribeGlobal(LocalListenerRef((uint16_t) type, listener));
  }

  IPC_RETURN_TYPE IpcFacade::subscribeToMsgs()
  {
    IPC_RETURN_TYPE status;
    status = subscribeDataCentral(MSG_BASE, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << MSG_BASE << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(RETURN_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << RETURN_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(BOOLEAN_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << BOOLEAN_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(INTEGER_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << INTEGER_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(REAL_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << REAL_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(STRING_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << STRING_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(BOOLEAN_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << BOOLEAN_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(INTEGER_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << INTEGER_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(REAL_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << REAL_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = subscribeDataCentral(STRING_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK, "IpcFacade::start: Error subscribing to " << STRING_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    // *** TODO: implement receiving planner update
    return status;
  }

  void IpcFacade::unsubscribeAll() {
    debugMsg("IpcFacade:unsubscribeAll", " entered");
    while (!m_localRegisteredHandlers.empty())
      unsubscribeAll(m_localRegisteredHandlers.front().second);
    debugMsg("IpcFacade:unsubscribeAll", " succeeded");
  }

  void IpcFacade::unsubscribeAll(IpcMessageListener* listener) {
    //prevent modification and access while removing
    RTMutexGuard guard(m_mutex);
    bool removed = false;
    for (LocalListenerList::iterator it = m_localRegisteredHandlers.begin();
         !removed && it != m_localRegisteredHandlers.end();
         it++) {
      if ((*it).second == listener) {
        unsubscribeGlobal(*it);
        m_localRegisteredHandlers.erase(it);
        removed = true;
      }
    }
  }

  IPC_RETURN_TYPE IpcFacade::unsubscribeFromMsgs()
  {
    IPC_RETURN_TYPE status;
    status = IPC_unsubscribe(MSG_BASE, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << MSG_BASE << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(RETURN_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << RETURN_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(BOOLEAN_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << BOOLEAN_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(INTEGER_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << INTEGER_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(REAL_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << REAL_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(STRING_VALUE_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << STRING_VALUE_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(BOOLEAN_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << BOOLEAN_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(INTEGER_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << INTEGER_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(REAL_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << REAL_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    status = IPC_unsubscribe(STRING_ARRAY_MSG, messageHandler);
    assertTrueMsg(status == IPC_OK,
                  "IpcFacade: Error unsubscribing from " << STRING_ARRAY_MSG << " messages, IPC_errno = " << IPC_errno);
    // *** TODO: implement receiving planner update
    return status;
  }

  /**
   * @brief publishes the given message via IPC
   * @param command The command string to send
   */
  uint32_t IpcFacade::publishMessage(std::string const &command) {
    assertTrue_2(m_isStarted, "publishMessage called before started");
    struct PlexilStringValueMsg packet = { { PlexilMsgType_Message, 0, getSerialNumber(), m_myUID.c_str() }, command.c_str() };
    return IPC_publishData(STRING_VALUE_MSG, (void *) &packet);
  }

  uint32_t IpcFacade::publishCommand(std::string const &command, std::vector<Value> const &argsToDeliver) {
    return sendCommand(command, "", argsToDeliver);
  }

  uint32_t IpcFacade::sendCommand(std::string const &command, std::string const &dest, std::vector<Value> const &argsToDeliver) {
    assertTrue_2(m_isStarted, "publishCommand called before started");
    uint32_t serial = getSerialNumber();
    struct PlexilStringValueMsg cmdPacket = { { PlexilMsgType_Command, argsToDeliver.size(), serial, m_myUID.c_str() }, command.c_str() };
    IPC_RETURN_TYPE result = IPC_publishData(formatMsgName(STRING_VALUE_MSG, dest).c_str(), (void *) &cmdPacket);
    if (result == IPC_OK) {
      result = sendParameters(argsToDeliver, serial);
      debugMsg("IpcFacade:publishCommand", "Command " << command << " published with serial " << serial);
    }
    setError(result);
    return result == IPC_OK ? serial : ERROR_SERIAL();
  }

  uint32_t IpcFacade::publishLookupNow(std::string const &lookup, std::vector<Value> const &argsToDeliver) {
    return sendLookupNow(lookup, "", argsToDeliver);
  }

  uint32_t IpcFacade::sendLookupNow(std::string const &lookup, std::string const &dest, std::vector<Value> const &argsToDeliver) {
    // Construct the messages
    // Leader
    uint32_t serial = getSerialNumber();
    struct PlexilStringValueMsg leader = { { PlexilMsgType_LookupNow, argsToDeliver.size(), serial, m_myUID.c_str() }, lookup.c_str() };

    IPC_RETURN_TYPE result;
    result = IPC_publishData(formatMsgName(STRING_VALUE_MSG, dest).c_str(), (void *) &leader);
    if (result == IPC_OK) {
      result = sendParameters(argsToDeliver, serial);
    }
    setError(result);
    return result == IPC_OK ? serial : ERROR_SERIAL();
  }

  uint32_t IpcFacade::publishReturnValues(uint32_t request_serial,
                                          std::string const &request_uid,
                                          Value const &arg)
  {
    assertTrue_2(m_isStarted, "publishReturnValues called before started");
    uint32_t serial = getSerialNumber();
    struct PlexilReturnValuesMsg packet = { { PlexilMsgType_ReturnValues, 1, serial, m_myUID.c_str() }, request_serial, request_uid.c_str() };
    IPC_RETURN_TYPE result = IPC_publishData(formatMsgName(RETURN_VALUE_MSG, request_uid).c_str(), (void *) &packet);
    if (result == IPC_OK) {
      result = sendParameters(std::vector<Value>(1, arg), serial, request_uid);
    }
    setError(result);
    return result == IPC_OK ? serial : ERROR_SERIAL();
  }

  IPC_RETURN_TYPE IpcFacade::getError() {
    return m_error;
  }

  void IpcFacade::setError(IPC_RETURN_TYPE error) {
    m_error = error;
  }

  uint32_t IpcFacade::publishTelemetry(const std::string& destName, std::vector<Value> const &values) {
    // Telemetry values message
    debugMsg("IpcFacade:publishTelemetry",
             " sending telemetry message for \"" << destName << "\"");
    PlexilStringValueMsg* tvMsg = new PlexilStringValueMsg();
    tvMsg->header.msgType = (uint16_t) PlexilMsgType_TelemetryValues;
    tvMsg->stringValue = destName.c_str();

    tvMsg->header.count = values.size();
    uint32_t leaderSerial = getSerialNumber();
    tvMsg->header.serial = leaderSerial;
    tvMsg->header.senderUID = m_myUID.c_str();
    IPC_RETURN_TYPE status = IPC_publishData(STRING_VALUE_MSG, (void *) tvMsg);
    if (status == IPC_OK) {
      status = sendParameters(values, leaderSerial);
    }
    setError(status);
    return status == IPC_OK ? leaderSerial : ERROR_SERIAL();
  }

  /**
   * @brief Helper function for sending a vector of parameters via IPC.
   * @param args The arguments to convert into messages and send
   * @param serial The serial to send along with each parameter. This should be the same serial as the header
   */
  IPC_RETURN_TYPE IpcFacade::sendParameters(std::vector<Value> const &args, uint32_t serial) {
    return sendParameters(args, serial, "");
  }

  /**
   * @brief Helper function for sending a vector of parameters via IPC to a specific executive.
   * @param args The arguments to convert into messages and send
   * @param serial The serial to send along with each parameter. This should be the same serial as the header
   * @param dest The destination executive name. If dest is an empty string, parameters are broadcast to
   * all executives
   */
  IPC_RETURN_TYPE IpcFacade::sendParameters(std::vector<Value> const &args, uint32_t serial, std::string const &dest) {
    size_t nParams = args.size();
    // Construct parameter messages
    PlexilMsgBase* paramMsgs[nParams];
    for (size_t i = 0; i < nParams; ++i) {
      PlexilMsgBase* paramMsg = constructPlexilValueMsg(args[i]);
      // Fill in common fields
      paramMsg->count = i;
      paramMsg->serial = serial;
      paramMsg->senderUID = m_myUID.c_str();
      paramMsgs[i] = paramMsg;
    }
    
    // Send the messages
    IPC_RETURN_TYPE result = IPC_OK;
    for (size_t i = 0; i < nParams && result == IPC_OK; i++) {
      std::string msgName = 
        formatMsgName(std::string(msgFormatForType((PlexilMsgType) paramMsgs[i]->msgType)),
                      dest);
      result = IPC_publishData(msgName.c_str(), paramMsgs[i]);
    }

    // free the parameter packets
    for (size_t i = 0; i < nParams; i++) {
      PlexilMsgBase* m = paramMsgs[i];
      paramMsgs[i] = NULL;
      switch (m->msgType) {
      case PlexilMsgType_UnknownValue:
        delete (PlexilUnknownValueMsg*) m;
        break;

      case PlexilMsgType_CommandHandleValue:
        delete (PlexilCommandHandleValueMsg*) m;
        break;

      case PlexilMsgType_BooleanValue:
        delete (PlexilBooleanValueMsg*) m;
        break;

      case PlexilMsgType_IntegerValue:
        delete (PlexilIntegerValueMsg*) m;
        break;

      case PlexilMsgType_RealValue:
        delete (PlexilRealValueMsg*) m;
        break;

      case PlexilMsgType_StringValue:
        delete (PlexilStringValueMsg*) m;
        break;

        // *** DON'T FREE ARRAY DATA! IPC does this. ***
      case PlexilMsgType_BooleanArray: {
        PlexilBooleanArrayMsg *bam = (PlexilBooleanArrayMsg*) m;
        delete bam;
        break;
      }

      case PlexilMsgType_IntegerArray: {
        PlexilIntegerArrayMsg *iam = (PlexilIntegerArrayMsg*) m;
        delete iam;
        break;
      }

      case PlexilMsgType_RealArray: {
        PlexilRealArrayMsg *ram = (PlexilRealArrayMsg*) m;
        delete ram;
        break;
      }

      case PlexilMsgType_StringArray: {
        PlexilStringArrayMsg *sam = (PlexilStringArrayMsg*) m;
        delete sam;
        break;
      }

      default:
        delete m;
        break;
      }
    }

    return result;
  }

  /**
   * @brief Get next serial number
   */
  uint32_t IpcFacade::getSerialNumber() {
    return m_nextSerial++;
  }

  bool IpcFacade::definePlexilIPCMessageTypes() {
    debugMsg("IpcFacade:definePlexilIPCMessageTypes", " entered");
    IPC_RETURN_TYPE status;
    status = IPC_defineMsg(MSG_BASE, IPC_VARIABLE_LENGTH, MSG_BASE_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(MSG_BASE), m_myUID).c_str(), IPC_VARIABLE_LENGTH, MSG_BASE_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(RETURN_VALUE_MSG, IPC_VARIABLE_LENGTH, RETURN_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(RETURN_VALUE_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, RETURN_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(BOOLEAN_VALUE_MSG, IPC_VARIABLE_LENGTH, BOOLEAN_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(BOOLEAN_VALUE_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, BOOLEAN_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(INTEGER_VALUE_MSG, IPC_VARIABLE_LENGTH, INTEGER_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(INTEGER_VALUE_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, INTEGER_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(REAL_VALUE_MSG, IPC_VARIABLE_LENGTH, REAL_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(REAL_VALUE_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, REAL_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(STRING_VALUE_MSG, IPC_VARIABLE_LENGTH, STRING_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(STRING_VALUE_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, STRING_VALUE_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(BOOLEAN_ARRAY_MSG, IPC_VARIABLE_LENGTH, BOOLEAN_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(BOOLEAN_ARRAY_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, BOOLEAN_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(INTEGER_ARRAY_MSG, IPC_VARIABLE_LENGTH, INTEGER_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(INTEGER_ARRAY_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, INTEGER_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(REAL_ARRAY_MSG, IPC_VARIABLE_LENGTH, REAL_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(REAL_ARRAY_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, REAL_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(STRING_ARRAY_MSG, IPC_VARIABLE_LENGTH, STRING_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(STRING_ARRAY_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, STRING_ARRAY_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(BOOLEAN_PAIR_MSG, IPC_VARIABLE_LENGTH, BOOLEAN_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(BOOLEAN_PAIR_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, BOOLEAN_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(INTEGER_PAIR_MSG, IPC_VARIABLE_LENGTH, INTEGER_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(INTEGER_PAIR_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, INTEGER_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(REAL_PAIR_MSG, IPC_VARIABLE_LENGTH, REAL_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(REAL_PAIR_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, REAL_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(STRING_PAIR_MSG, IPC_VARIABLE_LENGTH, STRING_PAIR_MSG_FORMAT);
    if (status != IPC_OK)
      return false;
    status = IPC_defineMsg(formatMsgName(std::string(STRING_PAIR_MSG), m_myUID).c_str(), IPC_VARIABLE_LENGTH, STRING_PAIR_MSG_FORMAT);
    condDebugMsg(status == IPC_OK, "IpcFacade:definePlexilIPCMessageTypes", " succeeded");
    return status == IPC_OK;
  }

  /**
   * @brief IPC listener thread top level function to replace IPC_dispatch().
   */
  void IpcFacade::myIpcDispatch(void * this_as_void_ptr)
  {
    IpcFacade* facade = reinterpret_cast<IpcFacade*>(this_as_void_ptr);
    assertTrueMsg(facade != NULL,
                  "IpcFacade::messageHandler: pointer to IpcFacade instance is null!");
    debugMsg("IpcFacade:myIpcDispatch", " started");
    IPC_RETURN_TYPE ipcStatus = IPC_OK;
    while (!facade->m_stopDispatchThread
           && ipcStatus != IPC_Error) {
      ipcStatus = IPC_listenClear(1000); // 
    }
    assertTrueMsg(ipcStatus != IPC_Error, "IpcFacade::myIpcDispatch: IPC error, IPC_errno = " << IPC_errno);
      
    facade->m_stopDispatchThread = false;
    debugMsg("IpcFacade:myIpcDispatch", " terminated");
  }

  /**
   * @brief Handler function as seen by IPC.
   */
  void IpcFacade::messageHandler(MSG_INSTANCE /* rawMsg */,
                                 void * unmarshalledMsg,
                                 void * this_as_void_ptr) {
    const PlexilMsgBase* msgData = reinterpret_cast<const PlexilMsgBase*> (unmarshalledMsg);
    assertTrueMsg(msgData != NULL,
                  "IpcFacade::messageHandler: pointer to message data is null!");
    IpcFacade* facade = reinterpret_cast<IpcFacade*>(this_as_void_ptr);
    assertTrueMsg(facade != NULL,
                  "IpcFacade::messageHandler: pointer to IpcFacade instance is null!");

    PlexilMsgType msgType = (PlexilMsgType) msgData->msgType;
    debugMsg("IpcFacade:messageHandler", " received message type = " << msgType);
    switch (msgType) {
      // LookupNow and LookupOnChange are PlexilStringValueMsg
      // Optionally followed by parameters

      // TODO: filter out commands/msgs we aren't prepared to handle
    case PlexilMsgType_Command:
    case PlexilMsgType_LookupNow:
    case PlexilMsgType_LookupOnChange:
    case PlexilMsgType_PlannerUpdate:
    case PlexilMsgType_TelemetryValues:
      debugMsg("IpcFacade:messageHandler", "processing as multi-part message");
      facade->cacheMessageLeader(msgData);
      break;

      // ReturnValues is a PlexilReturnValuesMsg
      // Followed by 0 (?) or more values
      // Only pay attention to return values directed at us
    case PlexilMsgType_ReturnValues: {
      debugMsg("IpcFacade:messageHandler", " processing as return value");
      const PlexilReturnValuesMsg* returnLeader = (const PlexilReturnValuesMsg*) msgData;
      if (strcmp(returnLeader->requesterUID, facade->getUID().c_str()) == 0)
        facade->cacheMessageLeader(msgData);
      break;
    }
      // Values - could be parameters or return values
    case PlexilMsgType_UnknownValue:
    case PlexilMsgType_BooleanValue:
    case PlexilMsgType_IntegerValue:
    case PlexilMsgType_RealValue:
    case PlexilMsgType_StringValue:
      // Arrays
    case PlexilMsgType_BooleanArray:
    case PlexilMsgType_IntegerArray:
    case PlexilMsgType_RealArray:
    case PlexilMsgType_StringArray:

      // PlannerUpdate pairs
    case PlexilMsgType_PairBoolean:
    case PlexilMsgType_PairInteger:
    case PlexilMsgType_PairReal:
    case PlexilMsgType_PairString:

      // Log with corresponding leader message
      facade->cacheMessageTrailer(msgData);
      break;

    default:
      debugMsg("IpcFacade:messageHandler", "Received single-message type, delivering to listeners");
      facade->deliverMessage(std::vector<const PlexilMsgBase*>(1, msgData));
      break;
    }
  }
  /**
   * @brief Cache start message of a multi-message sequence
   */

  // N.B. Presumes that messages are received in order.
  // Also presumes that any required filtering (e.g. on command name) has been done by the caller

  void IpcFacade::cacheMessageLeader(const PlexilMsgBase* msgData) {
    IpcMessageId msgId(msgData->senderUID, msgData->serial);

    // Check that this isn't a duplicate header
    IncompleteMessageMap::iterator it = m_incompletes.find(msgId);
    assertTrueMsg(it == m_incompletes.end(),
                  "IpcFacade::cacheMessageLeader: internal error: found existing sequence for sender "
                  << msgData->senderUID << ", serial " << msgData->serial);

    if (msgData->count == 0) {
      debugMsg("IpcFacade:cacheMessageLeader", " count == 0, processing immediately");
      std::vector<const PlexilMsgBase*> msgVec(1, msgData);
      deliverMessage(msgVec);
    } else {
      debugMsg("IpcFacade:cacheMessageLeader",
               " storing leader with sender " << msgData->senderUID << ", serial " << msgData->serial
               << ",\n expecting " << msgData->count << " values");
      m_incompletes[msgId] = std::vector<const PlexilMsgBase*>(1, msgData);
    }
  }

  /**
   * @brief Cache following message of a multi-message sequence
   */

  // N.B. Presumes that messages are received in order.

  void IpcFacade::cacheMessageTrailer(const PlexilMsgBase* msgData) {
    IpcMessageId msgId(msgData->senderUID, msgData->serial);
    IncompleteMessageMap::iterator it = m_incompletes.find(msgId);
    if (it == m_incompletes.end()) {
      debugMsg("IpcFacade::cacheMessageTrailer",
               " no existing sequence for sender "
               << msgData->senderUID << ", serial " << msgData->serial << ", ignoring");
      return;
    }
    std::vector<const PlexilMsgBase*>& msgs = it->second;
    msgs.push_back(msgData);
    // Have we got them all?
    if (msgs.size() > msgs[0]->count) {
      deliverMessage(msgs);
      m_incompletes.erase(it);
    }
  }

  /**
   * @brief Deliver the given message to all listeners registered for it
   */
  void IpcFacade::deliverMessage(const std::vector<const PlexilMsgBase*>& msgs) {
    if (!msgs.empty()) {
      //send to listeners for all
      ListenerMap::iterator map_it = m_registeredListeners.find(ALL_MSG_TYPE());
      if (map_it != m_registeredListeners.end()) {
        for (ListenerList::iterator it = (*map_it).second.begin(); it != (*map_it).second.end(); it++) {
          (*it)->ReceiveMessage(msgs);
        }
      }
      //send to listeners for msg type
      map_it = m_registeredListeners.find(msgs.front()->msgType);
      if (map_it != m_registeredListeners.end()) {
        for (ListenerList::iterator it = (*map_it).second.begin(); it != (*map_it).second.end(); it++) {
          (*it)->ReceiveMessage(msgs);
        }
      }

      // clean up
      for (size_t i = 0; i < msgs.size(); i++) {
        const PlexilMsgBase* msg = msgs[i];
        IPC_freeData(IPC_msgFormatter(msgFormatForType((PlexilMsgType) msg->msgType)), (void *) msg);
      }
    }
  }

  void IpcFacade::subscribeGlobal(const LocalListenerRef& listener) {
    //creates a new entry if one does not already exist
    m_registeredListeners[listener.first].push_back(listener.second);
  }

  /**
   * @brief Unsubscribe the given listener from the listener map.
   * @return True if found and unsubscribed. False if not found.
   */
  bool IpcFacade::unsubscribeGlobal(const LocalListenerRef& listener) {
    ListenerMap::iterator map_it = m_registeredListeners.find(listener.first);
    if (map_it != m_registeredListeners.end()) {
      for (ListenerList::iterator it = (*map_it).second.begin(); it != (*map_it).second.end(); it++) {
        if (listener.second == (*it)) {
          it = (*map_it).second.erase(it);
          return true;
        }
      }
    }
    return false;
  }

  /**
   * @brief Initialize unique ID string
   */
  std::string IpcFacade::generateUID() {
    kashmir::system::DevRand randomStream;
    kashmir::uuid_t uuid;
    randomStream >> uuid;
    std::ostringstream s;
    s << uuid;
    debugMsg("IpcFacade:generateUID", " generated UUID " << s.str());
    return s.str();
  }

  /**
   * Unsubscribes from the given message and the UID-specific version of the given message on central. Wrapper for IPC_unsubscribe.
   * If an error occurs in unsubscribing from the given message, the UID-specific version is not processed
   * @param msgName the name of the message to unsubscribe from
   * @param handler The handler to unsubscribe.
   */
  IPC_RETURN_TYPE IpcFacade::unsubscribeCentral (const char *msgName, HANDLER_TYPE handler) {
    IPC_RETURN_TYPE result = IPC_unsubscribe(msgName, handler);
    if (result == IPC_OK) {
      result = IPC_unsubscribe(formatMsgName(std::string(msgName), m_myUID).c_str(), handler);
    }
    return result;
  }

  /**
   * Subscribes from the given message and the UID-specific version of the given message on central. Wrapper for IPC_unsubscribe.
   * If an error occurs in subscribing from the given message, the UID-specific version is not processed
   * @param msgName the name of the message to subscribe from
   * @param handler The handler to subscribe.
   * @param clientData Pointer to data that will be passed to handler upon message receipt.
   */
  IPC_RETURN_TYPE IpcFacade::subscribeDataCentral (const char *msgName,
                                                   HANDLER_DATA_TYPE handler) {
    void* clientData = reinterpret_cast<void*>(this);
    debugMsg("IpcFacade:subscribeDataCentral", " for message name \"" << msgName << "\"");
    checkError(IPC_isMsgDefined(msgName),
               "IpcFacade::subscribeDataCentral: fatal error: message \"" << msgName << "\" not defined");
    IPC_RETURN_TYPE result = IPC_subscribeData(msgName, handler, clientData);
    if (result == IPC_OK) {
      result = IPC_subscribeData(formatMsgName(std::string(msgName), m_myUID).c_str(), handler, clientData);
    }
    condDebugMsg(result != IPC_OK,
                 "IpcFacade:subscribeDataCentral", " for message name \"" << msgName << "\" failed, IPC_errno = " << IPC_errno);
    return result;
  }

}
