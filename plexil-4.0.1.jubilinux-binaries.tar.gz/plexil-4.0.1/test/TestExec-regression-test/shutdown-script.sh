#!/bin/sh

mv -f .SavedDebug.cfg Debug.cfg
rm tempRegressionResults
